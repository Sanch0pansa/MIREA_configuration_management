if __name__ == "__main__":
    print("There is system")